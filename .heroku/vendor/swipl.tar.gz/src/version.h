/*  Generated file that contains the version identifier from
    the "git describe" command.

    DO NOT EDIT.   Check Makefile and mkversion.sh in src.
*/

#define GIT_VERSION "6.6.6-4-gd8142b5"
