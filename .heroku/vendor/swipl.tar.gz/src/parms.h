#ifndef PLHOME
#define PLHOME       "/app/lib/swipl-6.6.6"
#endif
#ifndef DEFSTARTUP
#define DEFSTARTUP   ".plrc"
#endif
#define PLVERSION 60606
#ifndef PLARCH
#define PLARCH	    "x86_64-linux"
#endif
#define C_LIBS	    ""
#define C_PLLIB	    "-lswipl"
#define C_LIBPLSO    ""
#ifndef C_CC
#define C_CC	    "gcc"
#endif
#ifndef C_CFLAGS
#define C_CFLAGS	    "-fno-strict-aliasing -pthread -fPIC "
#endif
#ifndef C_LDFLAGS
#define C_LDFLAGS    "-rdynamic -O2 -pthread -Wl,-rpath=/app/lib/swipl-6.6.6/lib/x86_64-linux "
#endif
